export default function App() {
  return (
    <div style={{ padding: '20px', fontFamily: 'Arial' }}>
      <h1 style={{ color: '#2563eb' }}>PMV</h1>
      <p>Career Transform. Everyone Gets Practical Knowledge.</p>
    </div>
  );
}
